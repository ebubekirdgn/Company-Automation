﻿namespace Otomasyon.Modul_Cari
{
    partial class DaoCariAcilisKarti
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DaoCariAcilisKarti));
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.textEdit1 = new DevExpress.XtraEditors.TextEdit();
            this.txtVergiNo = new DevExpress.XtraEditors.TextEdit();
            this.txtVergiDairesi = new DevExpress.XtraEditors.TextEdit();
            this.txtCariAdi = new DevExpress.XtraEditors.TextEdit();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.txtCariKodu = new DevExpress.XtraEditors.ButtonEdit();
            this.txtCariGrupAdi = new DevExpress.XtraEditors.TextEdit();
            this.txtCariGrupKodu = new DevExpress.XtraEditors.ButtonEdit();
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.txtYetkili2 = new DevExpress.XtraEditors.TextEdit();
            this.txtTelefon2 = new DevExpress.XtraEditors.TextEdit();
            this.txtMailInfo = new DevExpress.XtraEditors.TextEdit();
            this.txtSehir = new DevExpress.XtraEditors.TextEdit();
            this.labelControl18 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.txtYetkili2Email = new DevExpress.XtraEditors.TextEdit();
            this.txtFax2 = new DevExpress.XtraEditors.TextEdit();
            this.txtFax1 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl17 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl16 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.txtYetkili1 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl15 = new DevExpress.XtraEditors.LabelControl();
            this.txtIlce = new DevExpress.XtraEditors.TextEdit();
            this.labelControl14 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl19 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.txtYetkili1Email = new DevExpress.XtraEditors.TextEdit();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.txtTelefon1 = new DevExpress.XtraEditors.TextEdit();
            this.txtWebAdresi = new DevExpress.XtraEditors.TextEdit();
            this.labelControl20 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.txtUlke = new DevExpress.XtraEditors.TextEdit();
            this.txtAdres = new DevExpress.XtraEditors.MemoEdit();
            this.groupControl3 = new DevExpress.XtraEditors.GroupControl();
            this.BtnKapat = new DevExpress.XtraEditors.SimpleButton();
            this.BtnSil = new DevExpress.XtraEditors.SimpleButton();
            this.BtnKaydet = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtVergiNo.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtVergiDairesi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCariAdi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCariKodu.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCariGrupAdi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCariGrupKodu.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtYetkili2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTelefon2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMailInfo.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSehir.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtYetkili2Email.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFax2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFax1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtYetkili1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIlce.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtYetkili1Email.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTelefon1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtWebAdresi.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUlke.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAdres.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).BeginInit();
            this.groupControl3.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupControl1
            // 
            this.groupControl1.Controls.Add(this.textEdit1);
            this.groupControl1.Controls.Add(this.txtVergiNo);
            this.groupControl1.Controls.Add(this.txtVergiDairesi);
            this.groupControl1.Controls.Add(this.txtCariAdi);
            this.groupControl1.Controls.Add(this.labelControl6);
            this.groupControl1.Controls.Add(this.labelControl4);
            this.groupControl1.Controls.Add(this.labelControl3);
            this.groupControl1.Controls.Add(this.labelControl5);
            this.groupControl1.Controls.Add(this.labelControl2);
            this.groupControl1.Controls.Add(this.labelControl1);
            this.groupControl1.Controls.Add(this.txtCariKodu);
            this.groupControl1.Controls.Add(this.txtCariGrupAdi);
            this.groupControl1.Controls.Add(this.txtCariGrupKodu);
            this.groupControl1.Dock = System.Windows.Forms.DockStyle.Top;
            this.groupControl1.Location = new System.Drawing.Point(0, 0);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(624, 125);
            this.groupControl1.TabIndex = 0;
            this.groupControl1.Text = "Ön Cari Bilgileri";
            // 
            // textEdit1
            // 
            this.textEdit1.Location = new System.Drawing.Point(406, 55);
            this.textEdit1.Name = "textEdit1";
            this.textEdit1.Size = new System.Drawing.Size(195, 20);
            this.textEdit1.TabIndex = 4;
            // 
            // txtVergiNo
            // 
            this.txtVergiNo.Location = new System.Drawing.Point(406, 59);
            this.txtVergiNo.Name = "txtVergiNo";
            this.txtVergiNo.Size = new System.Drawing.Size(195, 20);
            this.txtVergiNo.TabIndex = 1;
            // 
            // txtVergiDairesi
            // 
            this.txtVergiDairesi.Location = new System.Drawing.Point(406, 27);
            this.txtVergiDairesi.Name = "txtVergiDairesi";
            this.txtVergiDairesi.Size = new System.Drawing.Size(195, 20);
            this.txtVergiDairesi.TabIndex = 3;
            // 
            // txtCariAdi
            // 
            this.txtCariAdi.Location = new System.Drawing.Point(97, 55);
            this.txtCariAdi.Name = "txtCariAdi";
            this.txtCariAdi.Size = new System.Drawing.Size(195, 20);
            this.txtCariAdi.TabIndex = 1;
            // 
            // labelControl6
            // 
            this.labelControl6.Location = new System.Drawing.Point(12, 88);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(79, 13);
            this.labelControl6.TabIndex = 0;
            this.labelControl6.Text = "Cari Grup Kodu :";
            // 
            // labelControl4
            // 
            this.labelControl4.Location = new System.Drawing.Point(305, 62);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(47, 13);
            this.labelControl4.TabIndex = 0;
            this.labelControl4.Text = "Vergi No :";
            // 
            // labelControl3
            // 
            this.labelControl3.Location = new System.Drawing.Point(305, 34);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(66, 13);
            this.labelControl3.TabIndex = 0;
            this.labelControl3.Text = "Vergi Dairesi :";
            // 
            // labelControl5
            // 
            this.labelControl5.Location = new System.Drawing.Point(305, 92);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(70, 13);
            this.labelControl5.TabIndex = 0;
            this.labelControl5.Text = "Cari Grup Adı :";
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(12, 58);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(44, 13);
            this.labelControl2.TabIndex = 0;
            this.labelControl2.Text = "Cari Adı :";
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(12, 30);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(53, 13);
            this.labelControl1.TabIndex = 0;
            this.labelControl1.Text = "Cari Kodu :";
            // 
            // txtCariKodu
            // 
            this.txtCariKodu.Location = new System.Drawing.Point(97, 27);
            this.txtCariKodu.Name = "txtCariKodu";
            this.txtCariKodu.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.txtCariKodu.Size = new System.Drawing.Size(195, 20);
            this.txtCariKodu.TabIndex = 0;
            this.txtCariKodu.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.txtCariKodu_ButtonClick);
            // 
            // txtCariGrupAdi
            // 
            this.txtCariGrupAdi.Location = new System.Drawing.Point(406, 85);
            this.txtCariGrupAdi.Name = "txtCariGrupAdi";
            this.txtCariGrupAdi.Size = new System.Drawing.Size(195, 20);
            this.txtCariGrupAdi.TabIndex = 5;
            // 
            // txtCariGrupKodu
            // 
            this.txtCariGrupKodu.Location = new System.Drawing.Point(97, 85);
            this.txtCariGrupKodu.Name = "txtCariGrupKodu";
            this.txtCariGrupKodu.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton()});
            this.txtCariGrupKodu.Size = new System.Drawing.Size(195, 20);
            this.txtCariGrupKodu.TabIndex = 2;
            this.txtCariGrupKodu.ButtonClick += new DevExpress.XtraEditors.Controls.ButtonPressedEventHandler(this.txtCariGrupKodu_ButtonClick);
            // 
            // groupControl2
            // 
            this.groupControl2.Controls.Add(this.txtYetkili2);
            this.groupControl2.Controls.Add(this.txtTelefon2);
            this.groupControl2.Controls.Add(this.txtMailInfo);
            this.groupControl2.Controls.Add(this.txtSehir);
            this.groupControl2.Controls.Add(this.labelControl18);
            this.groupControl2.Controls.Add(this.labelControl12);
            this.groupControl2.Controls.Add(this.txtYetkili2Email);
            this.groupControl2.Controls.Add(this.txtFax2);
            this.groupControl2.Controls.Add(this.txtFax1);
            this.groupControl2.Controls.Add(this.labelControl17);
            this.groupControl2.Controls.Add(this.labelControl16);
            this.groupControl2.Controls.Add(this.labelControl7);
            this.groupControl2.Controls.Add(this.txtYetkili1);
            this.groupControl2.Controls.Add(this.labelControl11);
            this.groupControl2.Controls.Add(this.labelControl15);
            this.groupControl2.Controls.Add(this.txtIlce);
            this.groupControl2.Controls.Add(this.labelControl14);
            this.groupControl2.Controls.Add(this.labelControl19);
            this.groupControl2.Controls.Add(this.labelControl10);
            this.groupControl2.Controls.Add(this.txtYetkili1Email);
            this.groupControl2.Controls.Add(this.labelControl8);
            this.groupControl2.Controls.Add(this.labelControl13);
            this.groupControl2.Controls.Add(this.txtTelefon1);
            this.groupControl2.Controls.Add(this.txtWebAdresi);
            this.groupControl2.Controls.Add(this.labelControl20);
            this.groupControl2.Controls.Add(this.labelControl9);
            this.groupControl2.Controls.Add(this.txtUlke);
            this.groupControl2.Controls.Add(this.txtAdres);
            this.groupControl2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.groupControl2.Location = new System.Drawing.Point(0, 125);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.Size = new System.Drawing.Size(624, 376);
            this.groupControl2.TabIndex = 0;
            this.groupControl2.Text = "Temel Cari Bilgiler";
            // 
            // txtYetkili2
            // 
            this.txtYetkili2.Location = new System.Drawing.Point(406, 151);
            this.txtYetkili2.Name = "txtYetkili2";
            this.txtYetkili2.Size = new System.Drawing.Size(195, 20);
            this.txtYetkili2.TabIndex = 10;
            // 
            // txtTelefon2
            // 
            this.txtTelefon2.Location = new System.Drawing.Point(88, 239);
            this.txtTelefon2.Name = "txtTelefon2";
            this.txtTelefon2.Size = new System.Drawing.Size(195, 20);
            this.txtTelefon2.TabIndex = 5;
            // 
            // txtMailInfo
            // 
            this.txtMailInfo.Location = new System.Drawing.Point(406, 60);
            this.txtMailInfo.Name = "txtMailInfo";
            this.txtMailInfo.Size = new System.Drawing.Size(195, 20);
            this.txtMailInfo.TabIndex = 7;
            // 
            // txtSehir
            // 
            this.txtSehir.Location = new System.Drawing.Point(88, 60);
            this.txtSehir.Name = "txtSehir";
            this.txtSehir.Size = new System.Drawing.Size(195, 20);
            this.txtSehir.TabIndex = 1;
            // 
            // labelControl18
            // 
            this.labelControl18.Location = new System.Drawing.Point(305, 126);
            this.labelControl18.Name = "labelControl18";
            this.labelControl18.Size = new System.Drawing.Size(65, 13);
            this.labelControl18.TabIndex = 0;
            this.labelControl18.Text = "Yetkili E-Mail :";
            // 
            // labelControl12
            // 
            this.labelControl12.Location = new System.Drawing.Point(12, 214);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(55, 13);
            this.labelControl12.TabIndex = 0;
            this.labelControl12.Text = "Telefon  1 :";
            // 
            // txtYetkili2Email
            // 
            this.txtYetkili2Email.Location = new System.Drawing.Point(406, 181);
            this.txtYetkili2Email.Name = "txtYetkili2Email";
            this.txtYetkili2Email.Size = new System.Drawing.Size(195, 20);
            this.txtYetkili2Email.TabIndex = 11;
            // 
            // txtFax2
            // 
            this.txtFax2.Location = new System.Drawing.Point(406, 235);
            this.txtFax2.Name = "txtFax2";
            this.txtFax2.Size = new System.Drawing.Size(195, 20);
            this.txtFax2.TabIndex = 13;
            // 
            // txtFax1
            // 
            this.txtFax1.Location = new System.Drawing.Point(406, 207);
            this.txtFax1.Name = "txtFax1";
            this.txtFax1.Size = new System.Drawing.Size(195, 20);
            this.txtFax1.TabIndex = 12;
            // 
            // labelControl17
            // 
            this.labelControl17.Location = new System.Drawing.Point(305, 35);
            this.labelControl17.Name = "labelControl17";
            this.labelControl17.Size = new System.Drawing.Size(62, 13);
            this.labelControl17.TabIndex = 0;
            this.labelControl17.Text = "Web Adresi :";
            // 
            // labelControl16
            // 
            this.labelControl16.Location = new System.Drawing.Point(305, 154);
            this.labelControl16.Name = "labelControl16";
            this.labelControl16.Size = new System.Drawing.Size(34, 13);
            this.labelControl16.TabIndex = 0;
            this.labelControl16.Text = "Yetkili :";
            // 
            // labelControl7
            // 
            this.labelControl7.Location = new System.Drawing.Point(12, 39);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(27, 13);
            this.labelControl7.TabIndex = 0;
            this.labelControl7.Text = "Ülke :";
            // 
            // txtYetkili1
            // 
            this.txtYetkili1.Location = new System.Drawing.Point(406, 90);
            this.txtYetkili1.Name = "txtYetkili1";
            this.txtYetkili1.Size = new System.Drawing.Size(195, 20);
            this.txtYetkili1.TabIndex = 8;
            // 
            // labelControl11
            // 
            this.labelControl11.Location = new System.Drawing.Point(15, 242);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(52, 13);
            this.labelControl11.TabIndex = 0;
            this.labelControl11.Text = "Telefon 2 :";
            // 
            // labelControl15
            // 
            this.labelControl15.Location = new System.Drawing.Point(305, 184);
            this.labelControl15.Name = "labelControl15";
            this.labelControl15.Size = new System.Drawing.Size(65, 13);
            this.labelControl15.TabIndex = 0;
            this.labelControl15.Text = "Yetkili E-Mail :";
            // 
            // txtIlce
            // 
            this.txtIlce.Location = new System.Drawing.Point(88, 90);
            this.txtIlce.Name = "txtIlce";
            this.txtIlce.Size = new System.Drawing.Size(195, 20);
            this.txtIlce.TabIndex = 2;
            // 
            // labelControl14
            // 
            this.labelControl14.Location = new System.Drawing.Point(305, 63);
            this.labelControl14.Name = "labelControl14";
            this.labelControl14.Size = new System.Drawing.Size(48, 13);
            this.labelControl14.TabIndex = 0;
            this.labelControl14.Text = "Mail Info :";
            // 
            // labelControl19
            // 
            this.labelControl19.Location = new System.Drawing.Point(305, 238);
            this.labelControl19.Name = "labelControl19";
            this.labelControl19.Size = new System.Drawing.Size(37, 13);
            this.labelControl19.TabIndex = 0;
            this.labelControl19.Text = "Fax 2 : ";
            // 
            // labelControl10
            // 
            this.labelControl10.Location = new System.Drawing.Point(305, 210);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(37, 13);
            this.labelControl10.TabIndex = 0;
            this.labelControl10.Text = "Fax 1 : ";
            // 
            // txtYetkili1Email
            // 
            this.txtYetkili1Email.Location = new System.Drawing.Point(406, 123);
            this.txtYetkili1Email.Name = "txtYetkili1Email";
            this.txtYetkili1Email.Size = new System.Drawing.Size(195, 20);
            this.txtYetkili1Email.TabIndex = 9;
            // 
            // labelControl8
            // 
            this.labelControl8.Location = new System.Drawing.Point(12, 67);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(31, 13);
            this.labelControl8.TabIndex = 0;
            this.labelControl8.Text = "Şehir :";
            // 
            // labelControl13
            // 
            this.labelControl13.Location = new System.Drawing.Point(305, 93);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(34, 13);
            this.labelControl13.TabIndex = 0;
            this.labelControl13.Text = "Yetkili :";
            // 
            // txtTelefon1
            // 
            this.txtTelefon1.Location = new System.Drawing.Point(88, 211);
            this.txtTelefon1.Name = "txtTelefon1";
            this.txtTelefon1.Size = new System.Drawing.Size(195, 20);
            this.txtTelefon1.TabIndex = 4;
            // 
            // txtWebAdresi
            // 
            this.txtWebAdresi.Location = new System.Drawing.Point(406, 32);
            this.txtWebAdresi.Name = "txtWebAdresi";
            this.txtWebAdresi.Size = new System.Drawing.Size(195, 20);
            this.txtWebAdresi.TabIndex = 6;
            // 
            // labelControl20
            // 
            this.labelControl20.Location = new System.Drawing.Point(12, 125);
            this.labelControl20.Name = "labelControl20";
            this.labelControl20.Size = new System.Drawing.Size(35, 13);
            this.labelControl20.TabIndex = 0;
            this.labelControl20.Text = "Adres :";
            // 
            // labelControl9
            // 
            this.labelControl9.Location = new System.Drawing.Point(12, 97);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(24, 13);
            this.labelControl9.TabIndex = 0;
            this.labelControl9.Text = "İlçe :";
            // 
            // txtUlke
            // 
            this.txtUlke.Location = new System.Drawing.Point(88, 32);
            this.txtUlke.Name = "txtUlke";
            this.txtUlke.Size = new System.Drawing.Size(195, 20);
            this.txtUlke.TabIndex = 0;
            // 
            // txtAdres
            // 
            this.txtAdres.Location = new System.Drawing.Point(88, 118);
            this.txtAdres.Name = "txtAdres";
            this.txtAdres.Size = new System.Drawing.Size(195, 83);
            this.txtAdres.TabIndex = 3;
            // 
            // groupControl3
            // 
            this.groupControl3.Controls.Add(this.BtnKapat);
            this.groupControl3.Controls.Add(this.BtnSil);
            this.groupControl3.Controls.Add(this.BtnKaydet);
            this.groupControl3.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.groupControl3.Location = new System.Drawing.Point(0, 426);
            this.groupControl3.Name = "groupControl3";
            this.groupControl3.Size = new System.Drawing.Size(624, 75);
            this.groupControl3.TabIndex = 2;
            // 
            // BtnKapat
            // 
            this.BtnKapat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnKapat.Image = global::Otomasyon.Properties.Resources.Kapat24x24;
            this.BtnKapat.Location = new System.Drawing.Point(523, 28);
            this.BtnKapat.Name = "BtnKapat";
            this.BtnKapat.Size = new System.Drawing.Size(89, 35);
            this.BtnKapat.TabIndex = 2;
            this.BtnKapat.Text = "Kapat";
            this.BtnKapat.Click += new System.EventHandler(this.BtnKapat_Click);
            // 
            // BtnSil
            // 
            this.BtnSil.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnSil.Image = global::Otomasyon.Properties.Resources.Sil24x24;
            this.BtnSil.Location = new System.Drawing.Point(430, 28);
            this.BtnSil.Name = "BtnSil";
            this.BtnSil.Size = new System.Drawing.Size(87, 35);
            this.BtnSil.TabIndex = 1;
            this.BtnSil.Text = "Sil";
            this.BtnSil.Click += new System.EventHandler(this.BtnSil_Click);
            // 
            // BtnKaydet
            // 
            this.BtnKaydet.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnKaydet.Image = global::Otomasyon.Properties.Resources.Kaydet24x24;
            this.BtnKaydet.Location = new System.Drawing.Point(336, 28);
            this.BtnKaydet.Name = "BtnKaydet";
            this.BtnKaydet.Size = new System.Drawing.Size(88, 35);
            this.BtnKaydet.TabIndex = 0;
            this.BtnKaydet.Text = "Kaydet";
            this.BtnKaydet.Click += new System.EventHandler(this.BtnKaydet_Click);
            // 
            // frmCariAcilisKarti
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(624, 501);
            this.Controls.Add(this.groupControl3);
            this.Controls.Add(this.groupControl2);
            this.Controls.Add(this.groupControl1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "frmCariAcilisKarti";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Cari Açılış Kartı";
            this.Load += new System.EventHandler(this.frmCariAcilisKarti_Load);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            this.groupControl1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.textEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtVergiNo.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtVergiDairesi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCariAdi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCariKodu.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCariGrupAdi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtCariGrupKodu.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            this.groupControl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.txtYetkili2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTelefon2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtMailInfo.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtSehir.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtYetkili2Email.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFax2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtFax1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtYetkili1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtIlce.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtYetkili1Email.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtTelefon1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtWebAdresi.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtUlke.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.txtAdres.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl3)).EndInit();
            this.groupControl3.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.GroupControl groupControl2;
        private DevExpress.XtraEditors.TextEdit txtCariAdi;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.TextEdit txtVergiNo;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.TextEdit txtVergiDairesi;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.TextEdit txtSehir;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.TextEdit txtIlce;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.TextEdit txtUlke;
        private DevExpress.XtraEditors.GroupControl groupControl3;
        private DevExpress.XtraEditors.SimpleButton BtnKapat;
        private DevExpress.XtraEditors.SimpleButton BtnSil;
        private DevExpress.XtraEditors.SimpleButton BtnKaydet;
        private DevExpress.XtraEditors.TextEdit txtTelefon2;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.TextEdit txtFax1;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.TextEdit txtTelefon1;
        private DevExpress.XtraEditors.TextEdit txtYetkili2;
        private DevExpress.XtraEditors.TextEdit txtMailInfo;
        private DevExpress.XtraEditors.LabelControl labelControl18;
        private DevExpress.XtraEditors.TextEdit txtYetkili2Email;
        private DevExpress.XtraEditors.LabelControl labelControl17;
        private DevExpress.XtraEditors.LabelControl labelControl16;
        private DevExpress.XtraEditors.TextEdit txtYetkili1;
        private DevExpress.XtraEditors.LabelControl labelControl15;
        private DevExpress.XtraEditors.LabelControl labelControl14;
        private DevExpress.XtraEditors.TextEdit txtYetkili1Email;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.TextEdit txtWebAdresi;
        private DevExpress.XtraEditors.TextEdit txtFax2;
        private DevExpress.XtraEditors.LabelControl labelControl19;
        private DevExpress.XtraEditors.LabelControl labelControl20;
        private DevExpress.XtraEditors.MemoEdit txtAdres;
        private DevExpress.XtraEditors.ButtonEdit txtCariKodu;
        private DevExpress.XtraEditors.TextEdit txtCariGrupAdi;
        private DevExpress.XtraEditors.ButtonEdit txtCariGrupKodu;
        private DevExpress.XtraEditors.TextEdit textEdit1;
    }
}
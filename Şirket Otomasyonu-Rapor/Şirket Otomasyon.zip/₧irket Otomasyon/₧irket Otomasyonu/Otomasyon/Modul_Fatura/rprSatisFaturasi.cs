﻿using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using DevExpress.XtraReports.UI;

namespace Otomasyon.Modul_Fatura
{
    public partial class rprSatisFaturasi : DevExpress.XtraReports.UI.XtraReport
    {
        public rprSatisFaturasi()
        {
            InitializeComponent();
        }

    }
}

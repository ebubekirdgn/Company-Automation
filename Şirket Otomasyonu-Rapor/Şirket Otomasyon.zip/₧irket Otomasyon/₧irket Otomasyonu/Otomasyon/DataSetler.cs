﻿namespace Otomasyon
{


    partial class DataSetler
    {
    }
}

﻿namespace Otomasyon
{
    partial class AnaForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AnaForm));
            this.ribbon = new DevExpress.XtraBars.Ribbon.RibbonControl();
            this.barBtnStokKarti = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnStokListesi = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnStokGruplari = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem4 = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnCariAcilisKarti = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnCariGruplari = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnCariListesi = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnCariHareketleri = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnAcilisKarti = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnParaTransferi = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnBankaListesi = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnBankaIsleri = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnBankaHareketleri = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnkasaAcilisKarti = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnKasaListesi = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnKasaDevirIslemKarti = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnKasaTahsilatOdeme = new DevExpress.XtraBars.BarButtonItem();
            this.barbtnSatisFaturasi = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnSatisIadeFaturasi = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnAlisFaturasi = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnAlisIadeFaturasi = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnSatisIrsaliyesi = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnAlisIrsaliyesi = new DevExpress.XtraBars.BarButtonItem();
            this.barStaticItem1 = new DevExpress.XtraBars.BarStaticItem();
            this.barStaticItem2 = new DevExpress.XtraBars.BarStaticItem();
            this.txtSaat = new DevExpress.XtraBars.BarStaticItem();
            this.barBtnKasaHareketleri = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnMusteriCek = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnKendiCekimiz = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnBankayaCekCikisi = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnCariyeCekCikisi = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnCekListesi = new DevExpress.XtraBars.BarButtonItem();
            this.barBtnKullanici = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem1 = new DevExpress.XtraBars.BarButtonItem();
            this.txtAltKullanici = new DevExpress.XtraBars.BarButtonItem();
            this.barButtonItem2 = new DevExpress.XtraBars.BarButtonItem();
            this.ribbonPage1 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup1 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage2 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup2 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage3 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup3 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage4 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup4 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonPage5 = new DevExpress.XtraBars.Ribbon.RibbonPage();
            this.ribbonPageGroup5 = new DevExpress.XtraBars.Ribbon.RibbonPageGroup();
            this.ribbonStatusBar = new DevExpress.XtraBars.Ribbon.RibbonStatusBar();
            this.xtraTabbedMdiManager1 = new DevExpress.XtraTabbedMdi.XtraTabbedMdiManager(this.components);
            this.navBarControl1 = new DevExpress.XtraNavBar.NavBarControl();
            this.navBarGroup1 = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBtnStokKarti = new DevExpress.XtraNavBar.NavBarItem();
            this.navBtnStokListesi = new DevExpress.XtraNavBar.NavBarItem();
            this.navBtnStokGruplari = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarGroup2 = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBtnCariAcilisKarti = new DevExpress.XtraNavBar.NavBarItem();
            this.navBtnCariGruplari = new DevExpress.XtraNavBar.NavBarItem();
            this.navBtnCariListesi = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarGroup3 = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBtnBankaAcilisKarti = new DevExpress.XtraNavBar.NavBarItem();
            this.navBtnBankaListesi = new DevExpress.XtraNavBar.NavBarItem();
            this.navBtnBankaIslemi = new DevExpress.XtraNavBar.NavBarItem();
            this.navBtnBankaHareketleri = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarGroup4 = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBtnKasaAcilisKarti = new DevExpress.XtraNavBar.NavBarItem();
            this.navBtnKasaListesi = new DevExpress.XtraNavBar.NavBarItem();
            this.navBtnKasaTahsilatOdeme = new DevExpress.XtraNavBar.NavBarItem();
            this.navBtnKasaHareketleri = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarGroup5 = new DevExpress.XtraNavBar.NavBarGroup();
            this.navBarItem5 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem6 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem8 = new DevExpress.XtraNavBar.NavBarItem();
            this.navBarItem9 = new DevExpress.XtraNavBar.NavBarItem();
            this.ALC = new DevExpress.XtraBars.Alerter.AlertControl(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.ribbon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabbedMdiManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.navBarControl1)).BeginInit();
            this.SuspendLayout();
            // 
            // ribbon
            // 
            this.ribbon.ExpandCollapseItem.Id = 0;
            this.ribbon.Items.AddRange(new DevExpress.XtraBars.BarItem[] {
            this.ribbon.ExpandCollapseItem,
            this.barBtnStokKarti,
            this.barBtnStokListesi,
            this.barBtnStokGruplari,
            this.barButtonItem4,
            this.barBtnCariAcilisKarti,
            this.barBtnCariGruplari,
            this.barBtnCariListesi,
            this.barBtnCariHareketleri,
            this.barBtnAcilisKarti,
            this.barBtnParaTransferi,
            this.barBtnBankaListesi,
            this.barBtnBankaIsleri,
            this.barBtnBankaHareketleri,
            this.barBtnkasaAcilisKarti,
            this.barBtnKasaListesi,
            this.barBtnKasaDevirIslemKarti,
            this.barBtnKasaTahsilatOdeme,
            this.barbtnSatisFaturasi,
            this.barBtnSatisIadeFaturasi,
            this.barBtnAlisFaturasi,
            this.barBtnAlisIadeFaturasi,
            this.barBtnSatisIrsaliyesi,
            this.barBtnAlisIrsaliyesi,
            this.barStaticItem1,
            this.barStaticItem2,
            this.txtSaat,
            this.barBtnKasaHareketleri,
            this.barBtnMusteriCek,
            this.barBtnKendiCekimiz,
            this.barBtnBankayaCekCikisi,
            this.barBtnCariyeCekCikisi,
            this.barBtnCekListesi,
            this.barBtnKullanici,
            this.barButtonItem1,
            this.txtAltKullanici,
            this.barButtonItem2});
            this.ribbon.Location = new System.Drawing.Point(0, 0);
            this.ribbon.MaxItemId = 44;
            this.ribbon.Name = "ribbon";
            this.ribbon.Pages.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPage[] {
            this.ribbonPage1,
            this.ribbonPage2,
            this.ribbonPage3,
            this.ribbonPage4,
            this.ribbonPage5});
            this.ribbon.Size = new System.Drawing.Size(882, 162);
            this.ribbon.StatusBar = this.ribbonStatusBar;
            this.ribbon.Toolbar.ItemLinks.Add(this.barBtnKullanici);
            this.ribbon.ToolbarLocation = DevExpress.XtraBars.Ribbon.RibbonQuickAccessToolbarLocation.Above;
            this.ribbon.Click += new System.EventHandler(this.ribbon_Click);
            // 
            // barBtnStokKarti
            // 
            this.barBtnStokKarti.Caption = "Stok Kartı";
            this.barBtnStokKarti.Glyph = global::Otomasyon.Properties.Resources.Stok_Kartı16x16;
            this.barBtnStokKarti.Id = 1;
            this.barBtnStokKarti.LargeGlyph = global::Otomasyon.Properties.Resources.Stok_Kartı32x32;
            this.barBtnStokKarti.Name = "barBtnStokKarti";
            this.barBtnStokKarti.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barBtnStokKarti_ItemClick);
            // 
            // barBtnStokListesi
            // 
            this.barBtnStokListesi.Caption = "Stok Listesi";
            this.barBtnStokListesi.Id = 2;
            this.barBtnStokListesi.LargeGlyph = global::Otomasyon.Properties.Resources.Stok_Liste32x32;
            this.barBtnStokListesi.Name = "barBtnStokListesi";
            this.barBtnStokListesi.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barBtnStokListesi_ItemClick);
            // 
            // barBtnStokGruplari
            // 
            this.barBtnStokGruplari.Caption = "Stok Grupları";
            this.barBtnStokGruplari.Id = 3;
            this.barBtnStokGruplari.LargeGlyph = global::Otomasyon.Properties.Resources.Stok_Grup32x32;
            this.barBtnStokGruplari.Name = "barBtnStokGruplari";
            this.barBtnStokGruplari.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barBtnStokGruplari_ItemClick);
            // 
            // barButtonItem4
            // 
            this.barButtonItem4.Caption = "Stok Hareketleri";
            this.barButtonItem4.Id = 4;
            this.barButtonItem4.LargeGlyph = global::Otomasyon.Properties.Resources.Stok_Hareket32x32;
            this.barButtonItem4.Name = "barButtonItem4";
            this.barButtonItem4.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem4_ItemClick);
            // 
            // barBtnCariAcilisKarti
            // 
            this.barBtnCariAcilisKarti.Caption = "Cari Açılış Kartı";
            this.barBtnCariAcilisKarti.Id = 5;
            this.barBtnCariAcilisKarti.LargeGlyph = global::Otomasyon.Properties.Resources.Cari_Kart32x32;
            this.barBtnCariAcilisKarti.Name = "barBtnCariAcilisKarti";
            this.barBtnCariAcilisKarti.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barBtnCariAcilisKarti_ItemClick);
            // 
            // barBtnCariGruplari
            // 
            this.barBtnCariGruplari.Caption = "Cari Grupları";
            this.barBtnCariGruplari.Id = 6;
            this.barBtnCariGruplari.LargeGlyph = global::Otomasyon.Properties.Resources.Cari_Grup32x32;
            this.barBtnCariGruplari.Name = "barBtnCariGruplari";
            this.barBtnCariGruplari.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barBtnCariGruplari_ItemClick);
            // 
            // barBtnCariListesi
            // 
            this.barBtnCariListesi.Caption = "Cari Listesi";
            this.barBtnCariListesi.Id = 7;
            this.barBtnCariListesi.LargeGlyph = global::Otomasyon.Properties.Resources.Cari_Liste32x32;
            this.barBtnCariListesi.Name = "barBtnCariListesi";
            this.barBtnCariListesi.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barBtnCariListesi_ItemClick);
            // 
            // barBtnCariHareketleri
            // 
            this.barBtnCariHareketleri.Caption = "Cari Hareketleri";
            this.barBtnCariHareketleri.Id = 8;
            this.barBtnCariHareketleri.LargeGlyph = global::Otomasyon.Properties.Resources.Cari_Hareket32x32;
            this.barBtnCariHareketleri.Name = "barBtnCariHareketleri";
            this.barBtnCariHareketleri.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barBtnCariHareketleri_ItemClick);
            // 
            // barBtnAcilisKarti
            // 
            this.barBtnAcilisKarti.Caption = "Banka Açılış Kartı";
            this.barBtnAcilisKarti.Id = 9;
            this.barBtnAcilisKarti.LargeGlyph = global::Otomasyon.Properties.Resources.Banka_Kartı32x32;
            this.barBtnAcilisKarti.LargeWidth = 100;
            this.barBtnAcilisKarti.Name = "barBtnAcilisKarti";
            this.barBtnAcilisKarti.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barBtnAcilisKarti_ItemClick);
            // 
            // barBtnParaTransferi
            // 
            this.barBtnParaTransferi.Id = 37;
            this.barBtnParaTransferi.Name = "barBtnParaTransferi";
            // 
            // barBtnBankaListesi
            // 
            this.barBtnBankaListesi.Caption = "Banka Listesi";
            this.barBtnBankaListesi.Id = 11;
            this.barBtnBankaListesi.LargeGlyph = global::Otomasyon.Properties.Resources.Banka_Liste32x32;
            this.barBtnBankaListesi.LargeWidth = 100;
            this.barBtnBankaListesi.Name = "barBtnBankaListesi";
            this.barBtnBankaListesi.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barBtnBankaListesi_ItemClick);
            // 
            // barBtnBankaIsleri
            // 
            this.barBtnBankaIsleri.Caption = "Banka İşlemi";
            this.barBtnBankaIsleri.Id = 12;
            this.barBtnBankaIsleri.LargeGlyph = global::Otomasyon.Properties.Resources.Banka_Islem32x32;
            this.barBtnBankaIsleri.LargeWidth = 100;
            this.barBtnBankaIsleri.Name = "barBtnBankaIsleri";
            this.barBtnBankaIsleri.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barBtnBankaIsleri_ItemClick);
            // 
            // barBtnBankaHareketleri
            // 
            this.barBtnBankaHareketleri.Caption = "Banka Hareketleri";
            this.barBtnBankaHareketleri.Id = 13;
            this.barBtnBankaHareketleri.LargeGlyph = global::Otomasyon.Properties.Resources.Banka_Hareket32x32;
            this.barBtnBankaHareketleri.LargeWidth = 100;
            this.barBtnBankaHareketleri.Name = "barBtnBankaHareketleri";
            this.barBtnBankaHareketleri.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barBtnBankaHareketleri_ItemClick);
            // 
            // barBtnkasaAcilisKarti
            // 
            this.barBtnkasaAcilisKarti.Caption = "Kasa Açılış Kartı";
            this.barBtnkasaAcilisKarti.Id = 14;
            this.barBtnkasaAcilisKarti.LargeGlyph = global::Otomasyon.Properties.Resources.Kasa_Karti32x32;
            this.barBtnkasaAcilisKarti.LargeWidth = 100;
            this.barBtnkasaAcilisKarti.Name = "barBtnkasaAcilisKarti";
            this.barBtnkasaAcilisKarti.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barBtnkasaAcilisKarti_ItemClick);
            // 
            // barBtnKasaListesi
            // 
            this.barBtnKasaListesi.Caption = "Kasa Listesi";
            this.barBtnKasaListesi.Id = 15;
            this.barBtnKasaListesi.LargeGlyph = global::Otomasyon.Properties.Resources.Kasa_Liste32x32;
            this.barBtnKasaListesi.LargeWidth = 100;
            this.barBtnKasaListesi.Name = "barBtnKasaListesi";
            this.barBtnKasaListesi.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barBtnKasaListesi_ItemClick);
            // 
            // barBtnKasaDevirIslemKarti
            // 
            this.barBtnKasaDevirIslemKarti.Id = 36;
            this.barBtnKasaDevirIslemKarti.Name = "barBtnKasaDevirIslemKarti";
            // 
            // barBtnKasaTahsilatOdeme
            // 
            this.barBtnKasaTahsilatOdeme.Caption = "Kasa Tahsilat/Ödeme ";
            this.barBtnKasaTahsilatOdeme.Id = 17;
            this.barBtnKasaTahsilatOdeme.LargeGlyph = global::Otomasyon.Properties.Resources.Kasa_Odeme32x32;
            this.barBtnKasaTahsilatOdeme.LargeWidth = 100;
            this.barBtnKasaTahsilatOdeme.Name = "barBtnKasaTahsilatOdeme";
            this.barBtnKasaTahsilatOdeme.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barBtnKasaTahsilatOdeme_ItemClick);
            // 
            // barbtnSatisFaturasi
            // 
            this.barbtnSatisFaturasi.Caption = "Satış Faturası";
            this.barbtnSatisFaturasi.Id = 18;
            this.barbtnSatisFaturasi.LargeGlyph = global::Otomasyon.Properties.Resources.Fatura_Satis32x32;
            this.barbtnSatisFaturasi.LargeWidth = 100;
            this.barbtnSatisFaturasi.Name = "barbtnSatisFaturasi";
            this.barbtnSatisFaturasi.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barbtnSatisFaturasi_ItemClick);
            // 
            // barBtnSatisIadeFaturasi
            // 
            this.barBtnSatisIadeFaturasi.Caption = "Satış İade Faturası";
            this.barBtnSatisIadeFaturasi.Id = 19;
            this.barBtnSatisIadeFaturasi.LargeGlyph = global::Otomasyon.Properties.Resources.Fatura_SatisIade32x32;
            this.barBtnSatisIadeFaturasi.LargeWidth = 100;
            this.barBtnSatisIadeFaturasi.Name = "barBtnSatisIadeFaturasi";
            this.barBtnSatisIadeFaturasi.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barBtnSatisIadeFaturasi_ItemClick);
            // 
            // barBtnAlisFaturasi
            // 
            this.barBtnAlisFaturasi.Caption = "Alış Faturası";
            this.barBtnAlisFaturasi.Id = 20;
            this.barBtnAlisFaturasi.LargeGlyph = global::Otomasyon.Properties.Resources.Fatura_Alis32x32;
            this.barBtnAlisFaturasi.LargeWidth = 100;
            this.barBtnAlisFaturasi.Name = "barBtnAlisFaturasi";
            // 
            // barBtnAlisIadeFaturasi
            // 
            this.barBtnAlisIadeFaturasi.Caption = "Alış İade Faturası";
            this.barBtnAlisIadeFaturasi.Id = 21;
            this.barBtnAlisIadeFaturasi.LargeGlyph = global::Otomasyon.Properties.Resources.Fatura_AlisIade32x32;
            this.barBtnAlisIadeFaturasi.LargeWidth = 100;
            this.barBtnAlisIadeFaturasi.Name = "barBtnAlisIadeFaturasi";
            // 
            // barBtnSatisIrsaliyesi
            // 
            this.barBtnSatisIrsaliyesi.Caption = "Satış İrsaliyesi";
            this.barBtnSatisIrsaliyesi.Id = 22;
            this.barBtnSatisIrsaliyesi.LargeGlyph = global::Otomasyon.Properties.Resources.Fatura_SatisIade32x32;
            this.barBtnSatisIrsaliyesi.LargeWidth = 100;
            this.barBtnSatisIrsaliyesi.Name = "barBtnSatisIrsaliyesi";
            // 
            // barBtnAlisIrsaliyesi
            // 
            this.barBtnAlisIrsaliyesi.Caption = "Alış İrsaliyesi";
            this.barBtnAlisIrsaliyesi.Id = 23;
            this.barBtnAlisIrsaliyesi.LargeGlyph = global::Otomasyon.Properties.Resources.Fatura_AlisIade32x32;
            this.barBtnAlisIrsaliyesi.LargeWidth = 100;
            this.barBtnAlisIrsaliyesi.Name = "barBtnAlisIrsaliyesi";
            // 
            // barStaticItem1
            // 
            this.barStaticItem1.Caption = "Genel Otomasyon Yazılımı";
            this.barStaticItem1.Id = 24;
            this.barStaticItem1.ItemAppearance.Disabled.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.barStaticItem1.ItemAppearance.Disabled.Options.UseFont = true;
            this.barStaticItem1.ItemAppearance.Hovered.BackColor = System.Drawing.Color.Lime;
            this.barStaticItem1.ItemAppearance.Hovered.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.barStaticItem1.ItemAppearance.Hovered.ForeColor = System.Drawing.Color.Red;
            this.barStaticItem1.ItemAppearance.Hovered.Options.UseBackColor = true;
            this.barStaticItem1.ItemAppearance.Hovered.Options.UseFont = true;
            this.barStaticItem1.ItemAppearance.Hovered.Options.UseForeColor = true;
            this.barStaticItem1.ItemAppearance.Normal.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.barStaticItem1.ItemAppearance.Normal.Options.UseFont = true;
            this.barStaticItem1.ItemAppearance.Pressed.Font = new System.Drawing.Font("Tahoma", 8.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))));
            this.barStaticItem1.ItemAppearance.Pressed.Options.UseFont = true;
            this.barStaticItem1.Name = "barStaticItem1";
            this.barStaticItem1.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // barStaticItem2
            // 
            this.barStaticItem2.Caption = "barStaticItem2";
            this.barStaticItem2.Id = 25;
            this.barStaticItem2.Name = "barStaticItem2";
            this.barStaticItem2.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // txtSaat
            // 
            this.txtSaat.Alignment = DevExpress.XtraBars.BarItemLinkAlignment.Right;
            this.txtSaat.Caption = "02.07.2016";
            this.txtSaat.Id = 26;
            this.txtSaat.ItemAppearance.Hovered.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Bold);
            this.txtSaat.ItemAppearance.Hovered.Options.UseFont = true;
            this.txtSaat.ItemAppearance.Normal.Font = new System.Drawing.Font("Tahoma", 8.25F, System.Drawing.FontStyle.Italic);
            this.txtSaat.ItemAppearance.Normal.Options.UseFont = true;
            this.txtSaat.Name = "txtSaat";
            this.txtSaat.TextAlignment = System.Drawing.StringAlignment.Near;
            // 
            // barBtnKasaHareketleri
            // 
            this.barBtnKasaHareketleri.Caption = "Kasa Hareketleri";
            this.barBtnKasaHareketleri.Id = 27;
            this.barBtnKasaHareketleri.LargeGlyph = global::Otomasyon.Properties.Resources.Kasa_Hareket32x32;
            this.barBtnKasaHareketleri.LargeWidth = 100;
            this.barBtnKasaHareketleri.Name = "barBtnKasaHareketleri";
            this.barBtnKasaHareketleri.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barBtnKasaHareketleri_ItemClick);
            // 
            // barBtnMusteriCek
            // 
            this.barBtnMusteriCek.Id = 38;
            this.barBtnMusteriCek.Name = "barBtnMusteriCek";
            // 
            // barBtnKendiCekimiz
            // 
            this.barBtnKendiCekimiz.Id = 39;
            this.barBtnKendiCekimiz.Name = "barBtnKendiCekimiz";
            // 
            // barBtnBankayaCekCikisi
            // 
            this.barBtnBankayaCekCikisi.Id = 40;
            this.barBtnBankayaCekCikisi.Name = "barBtnBankayaCekCikisi";
            // 
            // barBtnCariyeCekCikisi
            // 
            this.barBtnCariyeCekCikisi.Id = 41;
            this.barBtnCariyeCekCikisi.Name = "barBtnCariyeCekCikisi";
            // 
            // barBtnCekListesi
            // 
            this.barBtnCekListesi.Id = 42;
            this.barBtnCekListesi.Name = "barBtnCekListesi";
            // 
            // barBtnKullanici
            // 
            this.barBtnKullanici.Caption = "Kullanıcı Paneli";
            this.barBtnKullanici.Id = 33;
            this.barBtnKullanici.Name = "barBtnKullanici";
            this.barBtnKullanici.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barBtnKullanici_ItemClick);
            // 
            // barButtonItem1
            // 
            this.barButtonItem1.Caption = "Kullanıcı :";
            this.barButtonItem1.Id = 34;
            this.barButtonItem1.Name = "barButtonItem1";
            // 
            // txtAltKullanici
            // 
            this.txtAltKullanici.Id = 35;
            this.txtAltKullanici.Name = "txtAltKullanici";
            // 
            // barButtonItem2
            // 
            this.barButtonItem2.Caption = "Çıkış Yap";
            this.barButtonItem2.Id = 43;
            this.barButtonItem2.Name = "barButtonItem2";
            this.barButtonItem2.ItemClick += new DevExpress.XtraBars.ItemClickEventHandler(this.barButtonItem2_ItemClick);
            // 
            // ribbonPage1
            // 
            this.ribbonPage1.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup1});
            this.ribbonPage1.Image = global::Otomasyon.Properties.Resources.Stok32x32;
            this.ribbonPage1.Name = "ribbonPage1";
            this.ribbonPage1.Text = "Stok";
            // 
            // ribbonPageGroup1
            // 
            this.ribbonPageGroup1.ItemLinks.Add(this.barBtnStokKarti);
            this.ribbonPageGroup1.ItemLinks.Add(this.barBtnStokListesi);
            this.ribbonPageGroup1.ItemLinks.Add(this.barBtnStokGruplari);
            this.ribbonPageGroup1.Name = "ribbonPageGroup1";
            this.ribbonPageGroup1.Text = "Stok İşlemleri";
            // 
            // ribbonPage2
            // 
            this.ribbonPage2.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup2});
            this.ribbonPage2.Image = global::Otomasyon.Properties.Resources.Cari32x32;
            this.ribbonPage2.Name = "ribbonPage2";
            this.ribbonPage2.Text = "Cari";
            // 
            // ribbonPageGroup2
            // 
            this.ribbonPageGroup2.ItemLinks.Add(this.barBtnCariAcilisKarti);
            this.ribbonPageGroup2.ItemLinks.Add(this.barBtnCariGruplari);
            this.ribbonPageGroup2.ItemLinks.Add(this.barBtnCariListesi);
            this.ribbonPageGroup2.Name = "ribbonPageGroup2";
            this.ribbonPageGroup2.Text = "Cari İşlemler";
            // 
            // ribbonPage3
            // 
            this.ribbonPage3.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup3});
            this.ribbonPage3.Image = global::Otomasyon.Properties.Resources.Banka32x32;
            this.ribbonPage3.Name = "ribbonPage3";
            this.ribbonPage3.Text = "Banka";
            // 
            // ribbonPageGroup3
            // 
            this.ribbonPageGroup3.ItemLinks.Add(this.barBtnAcilisKarti);
            this.ribbonPageGroup3.ItemLinks.Add(this.barBtnBankaListesi);
            this.ribbonPageGroup3.ItemLinks.Add(this.barBtnBankaIsleri);
            this.ribbonPageGroup3.ItemLinks.Add(this.barBtnBankaHareketleri);
            this.ribbonPageGroup3.Name = "ribbonPageGroup3";
            this.ribbonPageGroup3.Text = "Banka İşlemleri";
            // 
            // ribbonPage4
            // 
            this.ribbonPage4.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup4});
            this.ribbonPage4.Image = global::Otomasyon.Properties.Resources.Kasa32x32;
            this.ribbonPage4.Name = "ribbonPage4";
            this.ribbonPage4.Text = "Kasa";
            // 
            // ribbonPageGroup4
            // 
            this.ribbonPageGroup4.ItemLinks.Add(this.barBtnkasaAcilisKarti);
            this.ribbonPageGroup4.ItemLinks.Add(this.barBtnKasaListesi);
            this.ribbonPageGroup4.ItemLinks.Add(this.barBtnKasaTahsilatOdeme);
            this.ribbonPageGroup4.ItemLinks.Add(this.barBtnKasaHareketleri);
            this.ribbonPageGroup4.Name = "ribbonPageGroup4";
            this.ribbonPageGroup4.Text = "Kasa İşlemleri";
            // 
            // ribbonPage5
            // 
            this.ribbonPage5.Groups.AddRange(new DevExpress.XtraBars.Ribbon.RibbonPageGroup[] {
            this.ribbonPageGroup5});
            this.ribbonPage5.Image = global::Otomasyon.Properties.Resources.Fatura32x32;
            this.ribbonPage5.Name = "ribbonPage5";
            this.ribbonPage5.Text = "Fatura ";
            // 
            // ribbonPageGroup5
            // 
            this.ribbonPageGroup5.ItemLinks.Add(this.barbtnSatisFaturasi);
            this.ribbonPageGroup5.ItemLinks.Add(this.barBtnSatisIadeFaturasi);
            this.ribbonPageGroup5.Name = "ribbonPageGroup5";
            this.ribbonPageGroup5.Text = "Fatura İşlemleri";
            // 
            // ribbonStatusBar
            // 
            this.ribbonStatusBar.ItemLinks.Add(this.barStaticItem1);
            this.ribbonStatusBar.ItemLinks.Add(this.txtSaat);
            this.ribbonStatusBar.ItemLinks.Add(this.barButtonItem1);
            this.ribbonStatusBar.ItemLinks.Add(this.txtAltKullanici);
            this.ribbonStatusBar.ItemLinks.Add(this.barButtonItem2);
            this.ribbonStatusBar.Location = new System.Drawing.Point(0, 553);
            this.ribbonStatusBar.Name = "ribbonStatusBar";
            this.ribbonStatusBar.Ribbon = this.ribbon;
            this.ribbonStatusBar.Size = new System.Drawing.Size(882, 31);
            // 
            // xtraTabbedMdiManager1
            // 
            this.xtraTabbedMdiManager1.ClosePageButtonShowMode = DevExpress.XtraTab.ClosePageButtonShowMode.InAllTabPageHeaders;
            this.xtraTabbedMdiManager1.MdiParent = this;
            this.xtraTabbedMdiManager1.UseFormIconAsPageImage = DevExpress.Utils.DefaultBoolean.True;
            // 
            // navBarControl1
            // 
            this.navBarControl1.ActiveGroup = this.navBarGroup1;
            this.navBarControl1.BorderStyle = DevExpress.XtraEditors.Controls.BorderStyles.NoBorder;
            this.navBarControl1.Dock = System.Windows.Forms.DockStyle.Left;
            this.navBarControl1.Groups.AddRange(new DevExpress.XtraNavBar.NavBarGroup[] {
            this.navBarGroup1,
            this.navBarGroup2,
            this.navBarGroup3,
            this.navBarGroup4,
            this.navBarGroup5});
            this.navBarControl1.Items.AddRange(new DevExpress.XtraNavBar.NavBarItem[] {
            this.navBtnStokKarti,
            this.navBtnStokListesi,
            this.navBtnStokGruplari,
            this.navBtnCariAcilisKarti,
            this.navBtnCariGruplari,
            this.navBtnCariListesi,
            this.navBtnBankaAcilisKarti,
            this.navBtnBankaListesi,
            this.navBtnBankaIslemi,
            this.navBtnBankaHareketleri,
            this.navBtnKasaAcilisKarti,
            this.navBtnKasaListesi,
            this.navBtnKasaTahsilatOdeme,
            this.navBtnKasaHareketleri});
            this.navBarControl1.Location = new System.Drawing.Point(0, 162);
            this.navBarControl1.Name = "navBarControl1";
            this.navBarControl1.OptionsNavPane.ExpandedWidth = 209;
            this.navBarControl1.Size = new System.Drawing.Size(209, 391);
            this.navBarControl1.TabIndex = 3;
            this.navBarControl1.Text = "navBarControl1";
            this.navBarControl1.View = new DevExpress.XtraNavBar.ViewInfo.StandardSkinNavigationPaneViewInfoRegistrator("DevExpress Style");
            this.navBarControl1.Click += new System.EventHandler(this.navBarControl1_Click);
            // 
            // navBarGroup1
            // 
            this.navBarGroup1.Caption = "Stok";
            this.navBarGroup1.Expanded = true;
            this.navBarGroup1.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBtnStokKarti),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBtnStokListesi),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBtnStokGruplari)});
            this.navBarGroup1.Name = "navBarGroup1";
            // 
            // navBtnStokKarti
            // 
            this.navBtnStokKarti.Caption = "Stok Kartı";
            this.navBtnStokKarti.Name = "navBtnStokKarti";
            this.navBtnStokKarti.SmallImage = global::Otomasyon.Properties.Resources.Stok_Kartı16x16;
            this.navBtnStokKarti.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBtnStokKarti_LinkClicked);
            // 
            // navBtnStokListesi
            // 
            this.navBtnStokListesi.Caption = "Stok Listesi";
            this.navBtnStokListesi.Name = "navBtnStokListesi";
            this.navBtnStokListesi.SmallImage = global::Otomasyon.Properties.Resources.Stok_Liste16x16;
            this.navBtnStokListesi.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBtnStokListesi_LinkClicked);
            // 
            // navBtnStokGruplari
            // 
            this.navBtnStokGruplari.Caption = "Stok Gruplari";
            this.navBtnStokGruplari.Name = "navBtnStokGruplari";
            this.navBtnStokGruplari.SmallImage = global::Otomasyon.Properties.Resources.Stok_Grup16x16;
            this.navBtnStokGruplari.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBtnStokGruplari_LinkClicked);
            // 
            // navBarGroup2
            // 
            this.navBarGroup2.Caption = "Cari";
            this.navBarGroup2.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBtnCariAcilisKarti),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBtnCariGruplari),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBtnCariListesi)});
            this.navBarGroup2.Name = "navBarGroup2";
            // 
            // navBtnCariAcilisKarti
            // 
            this.navBtnCariAcilisKarti.Caption = "Cari Açılış Kartı";
            this.navBtnCariAcilisKarti.Name = "navBtnCariAcilisKarti";
            this.navBtnCariAcilisKarti.SmallImage = global::Otomasyon.Properties.Resources.Cari_Kart16x16;
            this.navBtnCariAcilisKarti.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBtnCariAcilisKarti_LinkClicked);
            // 
            // navBtnCariGruplari
            // 
            this.navBtnCariGruplari.Caption = "Cari Grupları";
            this.navBtnCariGruplari.Name = "navBtnCariGruplari";
            this.navBtnCariGruplari.SmallImage = global::Otomasyon.Properties.Resources.Cari_Grup16x16;
            // 
            // navBtnCariListesi
            // 
            this.navBtnCariListesi.Caption = "Cari Listesi";
            this.navBtnCariListesi.Name = "navBtnCariListesi";
            this.navBtnCariListesi.SmallImage = global::Otomasyon.Properties.Resources.Cari_Liste16x16;
            // 
            // navBarGroup3
            // 
            this.navBarGroup3.Caption = "Banka";
            this.navBarGroup3.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBtnBankaAcilisKarti),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBtnBankaListesi),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBtnBankaIslemi),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBtnBankaHareketleri)});
            this.navBarGroup3.Name = "navBarGroup3";
            // 
            // navBtnBankaAcilisKarti
            // 
            this.navBtnBankaAcilisKarti.Caption = "Banka Açılış Kartı";
            this.navBtnBankaAcilisKarti.Name = "navBtnBankaAcilisKarti";
            this.navBtnBankaAcilisKarti.SmallImage = global::Otomasyon.Properties.Resources.Banka_Islem16x16;
            this.navBtnBankaAcilisKarti.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBtnBankaAcilisKarti_LinkClicked);
            // 
            // navBtnBankaListesi
            // 
            this.navBtnBankaListesi.Caption = "Banka Listesi";
            this.navBtnBankaListesi.Name = "navBtnBankaListesi";
            this.navBtnBankaListesi.SmallImage = global::Otomasyon.Properties.Resources.Banka_Liste16x16;
            this.navBtnBankaListesi.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBtnBankaListesi_LinkClicked);
            // 
            // navBtnBankaIslemi
            // 
            this.navBtnBankaIslemi.Caption = "Banka İşlemi";
            this.navBtnBankaIslemi.Name = "navBtnBankaIslemi";
            this.navBtnBankaIslemi.SmallImage = global::Otomasyon.Properties.Resources.Banka_Islem16x16;
            this.navBtnBankaIslemi.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBtnBankaIslemi_LinkClicked);
            // 
            // navBtnBankaHareketleri
            // 
            this.navBtnBankaHareketleri.Caption = "Banka Hareketleri";
            this.navBtnBankaHareketleri.Name = "navBtnBankaHareketleri";
            this.navBtnBankaHareketleri.SmallImage = global::Otomasyon.Properties.Resources.Banka_Hareket16x16;
            this.navBtnBankaHareketleri.LinkClicked += new DevExpress.XtraNavBar.NavBarLinkEventHandler(this.navBtnBankaHareketleri_LinkClicked);
            // 
            // navBarGroup4
            // 
            this.navBarGroup4.Caption = "Kasa";
            this.navBarGroup4.ItemLinks.AddRange(new DevExpress.XtraNavBar.NavBarItemLink[] {
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBtnKasaAcilisKarti),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBtnKasaListesi),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBtnKasaTahsilatOdeme),
            new DevExpress.XtraNavBar.NavBarItemLink(this.navBtnKasaHareketleri)});
            this.navBarGroup4.Name = "navBarGroup4";
            // 
            // navBtnKasaAcilisKarti
            // 
            this.navBtnKasaAcilisKarti.Caption = "Kasa Açılış Kartı";
            this.navBtnKasaAcilisKarti.Name = "navBtnKasaAcilisKarti";
            this.navBtnKasaAcilisKarti.SmallImage = global::Otomasyon.Properties.Resources.Kasa_Karti16x16;
            // 
            // navBtnKasaListesi
            // 
            this.navBtnKasaListesi.Caption = "Kasa Listesi";
            this.navBtnKasaListesi.Name = "navBtnKasaListesi";
            this.navBtnKasaListesi.SmallImage = global::Otomasyon.Properties.Resources.Kasa_Liste16x16;
            // 
            // navBtnKasaTahsilatOdeme
            // 
            this.navBtnKasaTahsilatOdeme.Caption = "Kasa Tahsilat/Ödeme";
            this.navBtnKasaTahsilatOdeme.Name = "navBtnKasaTahsilatOdeme";
            this.navBtnKasaTahsilatOdeme.SmallImage = global::Otomasyon.Properties.Resources.Kasa_Tahsilat16x16;
            // 
            // navBtnKasaHareketleri
            // 
            this.navBtnKasaHareketleri.Caption = "Kasa Hareketleri";
            this.navBtnKasaHareketleri.Name = "navBtnKasaHareketleri";
            this.navBtnKasaHareketleri.SmallImage = global::Otomasyon.Properties.Resources.Kasa_Hareket16x16;
            // 
            // navBarGroup5
            // 
            this.navBarGroup5.Caption = "Fatura";
            this.navBarGroup5.Name = "navBarGroup5";
            // 
            // navBarItem5
            // 
            this.navBarItem5.Caption = "navBarItem1";
            this.navBarItem5.Name = "navBarItem5";
            // 
            // navBarItem6
            // 
            this.navBarItem6.Caption = "navBarItem1";
            this.navBarItem6.Name = "navBarItem6";
            // 
            // navBarItem8
            // 
            this.navBarItem8.Caption = "navBarItem1";
            this.navBarItem8.Name = "navBarItem8";
            // 
            // navBarItem9
            // 
            this.navBarItem9.Caption = "navBarItem1";
            this.navBarItem9.Name = "navBarItem9";
            // 
            // AnaForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(882, 584);
            this.Controls.Add(this.navBarControl1);
            this.Controls.Add(this.ribbonStatusBar);
            this.Controls.Add(this.ribbon);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.IsMdiContainer = true;
            this.Name = "AnaForm";
            this.Ribbon = this.ribbon;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.StatusBar = this.ribbonStatusBar;
            this.Text = "Ana Form";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.Load += new System.EventHandler(this.AnaForm_Load);
            ((System.ComponentModel.ISupportInitialize)(this.ribbon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.xtraTabbedMdiManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.navBarControl1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraBars.Ribbon.RibbonControl ribbon;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage1;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup1;
        private DevExpress.XtraBars.Ribbon.RibbonStatusBar ribbonStatusBar;
        private DevExpress.XtraBars.BarButtonItem barBtnStokKarti;
        private DevExpress.XtraBars.BarButtonItem barBtnStokListesi;
        private DevExpress.XtraBars.BarButtonItem barBtnStokGruplari;
        private DevExpress.XtraBars.BarButtonItem barButtonItem4;
        private DevExpress.XtraTabbedMdi.XtraTabbedMdiManager xtraTabbedMdiManager1;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage2;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup2;
        private DevExpress.XtraBars.BarButtonItem barBtnCariAcilisKarti;
        private DevExpress.XtraBars.BarButtonItem barBtnCariGruplari;
        private DevExpress.XtraBars.BarButtonItem barBtnCariListesi;
        private DevExpress.XtraBars.BarButtonItem barBtnCariHareketleri;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage3;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup3;
        private DevExpress.XtraBars.BarButtonItem barBtnAcilisKarti;
        private DevExpress.XtraBars.BarButtonItem barBtnParaTransferi;
        private DevExpress.XtraBars.BarButtonItem barBtnBankaListesi;
        private DevExpress.XtraBars.BarButtonItem barBtnBankaIsleri;
        private DevExpress.XtraBars.BarButtonItem barBtnBankaHareketleri;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage4;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup4;
        private DevExpress.XtraBars.BarButtonItem barBtnkasaAcilisKarti;
        private DevExpress.XtraBars.BarButtonItem barBtnKasaListesi;
        private DevExpress.XtraBars.BarButtonItem barBtnKasaDevirIslemKarti;
        private DevExpress.XtraBars.BarButtonItem barBtnKasaTahsilatOdeme;
        private DevExpress.XtraBars.Ribbon.RibbonPage ribbonPage5;
        private DevExpress.XtraBars.Ribbon.RibbonPageGroup ribbonPageGroup5;
        private DevExpress.XtraBars.BarButtonItem barbtnSatisFaturasi;
        private DevExpress.XtraBars.BarButtonItem barBtnSatisIadeFaturasi;
        private DevExpress.XtraBars.BarButtonItem barBtnAlisFaturasi;
        private DevExpress.XtraBars.BarButtonItem barBtnAlisIadeFaturasi;
        private DevExpress.XtraBars.BarButtonItem barBtnSatisIrsaliyesi;
        private DevExpress.XtraBars.BarButtonItem barBtnAlisIrsaliyesi;
        private DevExpress.XtraBars.BarStaticItem barStaticItem1;
        private DevExpress.XtraBars.BarStaticItem barStaticItem2;
        private DevExpress.XtraBars.BarStaticItem txtSaat;
        private DevExpress.XtraBars.BarButtonItem barBtnKasaHareketleri;
        private DevExpress.XtraNavBar.NavBarControl navBarControl1;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup1;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup2;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup3;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup4;
        private DevExpress.XtraNavBar.NavBarGroup navBarGroup5;
        private DevExpress.XtraNavBar.NavBarItem navBtnStokKarti;
        private DevExpress.XtraNavBar.NavBarItem navBtnStokListesi;
        private DevExpress.XtraNavBar.NavBarItem navBtnStokGruplari;
        private DevExpress.XtraNavBar.NavBarItem navBtnCariAcilisKarti;
        private DevExpress.XtraNavBar.NavBarItem navBtnCariGruplari;
        private DevExpress.XtraNavBar.NavBarItem navBtnCariListesi;
        private DevExpress.XtraNavBar.NavBarItem navBarItem5;
        private DevExpress.XtraNavBar.NavBarItem navBarItem6;
        private DevExpress.XtraNavBar.NavBarItem navBtnBankaAcilisKarti;
        private DevExpress.XtraNavBar.NavBarItem navBtnBankaListesi;
        private DevExpress.XtraNavBar.NavBarItem navBtnBankaIslemi;
        private DevExpress.XtraNavBar.NavBarItem navBtnBankaHareketleri;
        private DevExpress.XtraNavBar.NavBarItem navBtnKasaAcilisKarti;
        private DevExpress.XtraNavBar.NavBarItem navBtnKasaListesi;
        private DevExpress.XtraNavBar.NavBarItem navBtnKasaTahsilatOdeme;
        private DevExpress.XtraNavBar.NavBarItem navBtnKasaHareketleri;
        private DevExpress.XtraNavBar.NavBarItem navBarItem8;
        private DevExpress.XtraNavBar.NavBarItem navBarItem9;
        private DevExpress.XtraBars.Alerter.AlertControl ALC;
        private DevExpress.XtraBars.BarButtonItem barBtnMusteriCek;
        private DevExpress.XtraBars.BarButtonItem barBtnKendiCekimiz;
        private DevExpress.XtraBars.BarButtonItem barBtnBankayaCekCikisi;
        private DevExpress.XtraBars.BarButtonItem barBtnCariyeCekCikisi;
        private DevExpress.XtraBars.BarButtonItem barBtnCekListesi;
        private DevExpress.XtraBars.BarButtonItem barBtnKullanici;
        private DevExpress.XtraBars.BarButtonItem barButtonItem1;
        private DevExpress.XtraBars.BarButtonItem txtAltKullanici;
        private DevExpress.XtraBars.BarButtonItem barButtonItem2;
    }
}